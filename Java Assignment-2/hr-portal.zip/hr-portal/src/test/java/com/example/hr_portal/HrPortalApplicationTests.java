package com.example.hr_portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
